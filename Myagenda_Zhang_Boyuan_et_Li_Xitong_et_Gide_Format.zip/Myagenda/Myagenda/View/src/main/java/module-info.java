module com.calendar.view {

    requires java.logging;

    requires transitive javafx.controls;
    requires transitive org.controlsfx.controls;
    requires transitive org.kordamp.ikonli.javafx;
    requires transitive org.kordamp.ikonli.fontawesome;
    requires java.desktop;
    requires ical4j.core;
    exports calendar.model;
    exports calendar.util;
    exports calendar.view;
    exports calendar.view.page;
    exports calendar.view.popover;
    exports calendar.view.print;

    exports impl.calendar.view;
    exports impl.calendar.view.page;
    exports impl.calendar.view.popover;
    exports impl.calendar.view.print;
    exports impl.calendar.view.util;

    opens calendar.view;
    opens calendar.model;
    opens impl.calendar.view;
}