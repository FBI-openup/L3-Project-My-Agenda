/*xitong li,boyuan zhang*/

package calendar.view.popover;

import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Accordion;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.BorderPane;

public class PopOverContentPane extends BorderPane {

    public PopOverContentPane() {
        super();

        topProperty().bind(headerProperty());

        Accordion accordion = new Accordion();
        accordion.getStyleClass().add("popover-accordion");
        setCenter(accordion);

        Bindings.bindContentBidirectional(getPanes(), accordion.getPanes());
        Bindings.bindBidirectional(expandedPaneProperty(), accordion.expandedPaneProperty());

        bottomProperty().bind(footerProperty());

        headerProperty().addListener((value, oldNode, newNode) -> {
            if (newNode != null) {
                String style = "popover-header";
                if (!newNode.getStyleClass().contains(style)) {
                    newNode.getStyleClass().add(style);
                }
            }
        });

        footerProperty().addListener((value, oldNode, newNode) -> {
            if (newNode != null) {
                String style = "popover-footer";
                if (!newNode.getStyleClass().contains(style)) {
                    newNode.getStyleClass().add(style);
                }
            }
        });
    }

    // header support

    private final ObjectProperty<Node> header = new SimpleObjectProperty<>(this, "header");

    public final ObjectProperty<Node> headerProperty() {
        return header;
    }

    public final Node getHeader() {
        return headerProperty().get();
    }

    public final void setHeader(Node node) {
        headerProperty().set(node);
    }

    // footer support

    private final ObjectProperty<Node> footer = new SimpleObjectProperty<>(this, "footer");

    public final ObjectProperty<Node> footerProperty() {
        return footer;
    }

    public final Node getFooter() {
        return footerProperty().get();
    }

    public final void setFooter(Node node) {
        footerProperty().set(node);
    }

    // panes

    private final ObservableList<TitledPane> panes = FXCollections.observableArrayList();

    public final ObservableList<TitledPane> getPanes() {
        return panes;
    }

    // Expanded pane support

    private final ObjectProperty<TitledPane> expandedPane = new SimpleObjectProperty<>(this, "expandedPane");

    public final ObjectProperty<TitledPane> expandedPaneProperty() {
        return expandedPane;
    }

    public final void setExpandedPane(TitledPane titledPane) {
        expandedPaneProperty().set(titledPane);
    }

    public final TitledPane getExpandedPane() {
        return expandedPane.get();
    }
}
