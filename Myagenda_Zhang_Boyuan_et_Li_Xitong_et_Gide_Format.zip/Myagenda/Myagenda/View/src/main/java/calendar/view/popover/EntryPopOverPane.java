/*xitong li,boyuan zhang*/

package calendar.view.popover;

import calendar.view.CalendarView;
import javafx.scene.layout.StackPane;

public abstract class EntryPopOverPane extends StackPane {

    public EntryPopOverPane() {
        getStylesheets().add(CalendarView.class.getResource("calendar.css").toExternalForm());
    }
}
