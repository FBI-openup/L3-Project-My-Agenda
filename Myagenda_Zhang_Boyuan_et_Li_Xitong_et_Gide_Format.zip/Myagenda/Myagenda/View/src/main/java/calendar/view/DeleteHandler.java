
package calendar.view;

import calendar.model.Calendar;
import calendar.model.Entry;
import javafx.scene.input.KeyEvent;

import static java.util.Objects.requireNonNull;

class DeleteHandler {

    protected final DateControl dateControl;

    public DeleteHandler(DateControl control) {
        this.dateControl = requireNonNull(control);
        dateControl.addEventHandler(KeyEvent.KEY_PRESSED, this::deleteEntries);
    }

    private void deleteEntries(KeyEvent evt) {
        switch (evt.getCode()) {
            case DELETE:
            case BACK_SPACE:
                for (Entry<?> entry : dateControl.getSelections()) {
                    if (!dateControl.getEntryEditPolicy().call(new DateControl.EntryEditParameter(dateControl, entry, DateControl.EditOperation.DELETE))) {
                        continue;
                    }
                    if (entry.isRecurrence()) {
                        entry = entry.getRecurrenceSourceEntry();
                    }
                    if (!dateControl.getEntryEditPolicy().call(new DateControl.EntryEditParameter(dateControl, entry, DateControl.EditOperation.DELETE))) {
                        continue;
                    }

                    Calendar calendar = entry.getCalendar();
                    if (calendar != null && !calendar.isReadOnly()) {
                        entry.removeFromCalendar();
                    }
                }
                dateControl.clearSelection();
                break;
            case F5:
                dateControl.refreshData();
            default:
                break;
        }
    }
}