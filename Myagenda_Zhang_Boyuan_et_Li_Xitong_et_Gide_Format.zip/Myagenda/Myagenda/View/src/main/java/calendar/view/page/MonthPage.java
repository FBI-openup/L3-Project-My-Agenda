/*xitong li,boyuan zhang*/

package calendar.view.page;

import calendar.view.print.ViewType;
import calendar.view.Messages;
import calendar.view.MonthView;
import impl.calendar.view.page.MonthPageSkin;
import javafx.scene.control.Skin;

import java.time.format.DateTimeFormatter;

/**
 * A composite view focused on displaying calendar information for a single
 * month. The view consists of the page "chrome" inherited from the superclass
 * and a {@link MonthView}.
 *
 * <img width="100%" src="doc-files/month-page.png" alt="Month Page">
 */
public class MonthPage extends PageBase {

    private final MonthView monthView;

    /**
     * Constructs a new month page.
     */
    public MonthPage() {
        super();

        getStyleClass().add("month-page");

        this.monthView = new MonthView();

        setDateTimeFormatter(DateTimeFormatter.ofPattern(Messages.getString("MonthPage.DATE_FORMAT")));
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new MonthPageSkin(this);
    }

    /**
     * Returns the week view child control. Most of the visualization in this
     * page is done by this view. The page only adds its chrome.
     *
     * @return the week view
     */
    public final MonthView getMonthView() {
        return monthView;
    }

    @Override
    public final void goForward() {
        setDate(getDate().plusMonths(1).withDayOfMonth(1));
    }

    @Override
    public final void goBack() {
        setDate(getDate().minusMonths(1).withDayOfMonth(1));
    }

    @Override
    public final ViewType getPrintViewType() {
        return ViewType.MONTH_VIEW;
    }

}
