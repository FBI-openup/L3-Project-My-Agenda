/*xitong li,boyuan zhang*/

package calendar.view.popover;

import calendar.model.Entry;
import org.controlsfx.control.PropertySheet;
import org.controlsfx.property.BeanPropertyUtils;

/**
 * Created by lemmi on 20.03.17.
 */
public class EntryPropertiesView extends EntryPopOverPane {

    public EntryPropertiesView(Entry<?> entry) {
        getStyleClass().add("no-padding");
        PropertySheet propertySheet = new PropertySheet();
        propertySheet.getItems().setAll(BeanPropertyUtils.getProperties(entry));
        getChildren().add(propertySheet);
    }
}
