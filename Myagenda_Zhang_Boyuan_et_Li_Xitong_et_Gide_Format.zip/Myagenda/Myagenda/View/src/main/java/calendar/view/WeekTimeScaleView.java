

package calendar.view;

import impl.calendar.view.WeekTimeScaleViewSkin;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.MapChangeListener;
import javafx.scene.control.Skin;

import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

/**
 * A specialization of the regular {@link TimeScaleView} to support a reference
 * to the {@link WeekView} where this scale is being used.
 */
public class WeekTimeScaleView extends TimeScaleView {

    private final ObjectProperty<DateTimeFormatter> formatter = new SimpleObjectProperty<>(this, "formatter", DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT));

    /**
     * Constructs a new scale view.
     */
    public WeekTimeScaleView() {
        MapChangeListener<? super Object, ? super Object> propertiesListener = change -> {
            if (change.wasAdded()) {
                if (change.getKey().equals("week.view")) {
                    detailedWeekView.set((DetailedWeekView) change.getValueAdded());
                }
            }
        };

        getProperties().addListener(propertiesListener);
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new WeekTimeScaleViewSkin(this);
    }

    private final ReadOnlyObjectWrapper<DetailedWeekView> detailedWeekView = new ReadOnlyObjectWrapper<>(this, "detailedWeekView");

    /**
     * The week view where this scale is being used.
     *
     * @return the week view
     */
    public final ReadOnlyObjectProperty<DetailedWeekView> detailedWeekViewProperty() {
        return detailedWeekView.getReadOnlyProperty();
    }

    /**
     * Returns the value of {@link #detailedWeekViewProperty()}.
     *
     * @return the week view
     */
    public final DetailedWeekView getDetailedWeekView() {
        return detailedWeekView.get();
    }

    @Override
    protected ObjectProperty<DateTimeFormatter> timeFormatterProperty() {
        return formatter;
    }

    @Override
    public void setTimeFormatter(DateTimeFormatter formatter) {
        timeFormatterProperty().set(formatter);
    }
}
