

package calendar.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Control;
import org.controlsfx.control.PropertySheet;
import org.controlsfx.control.PropertySheet.Item;

/**
 * Common superclass for all controls in the calendar framework.
 */
public abstract class CalendarControl extends Control {

    private static String stylesheet;

    /**
     * Constructs a new control.
     */
    protected CalendarControl() {
    }

    @Override
    public final String getUserAgentStylesheet() {
        if (stylesheet == null) {
            stylesheet = CalendarControl.class.getResource("calendar.css").toExternalForm();
        }
        return stylesheet;
    }

    /**
     * Returns a list of property items that can be shown by the
     * {@link PropertySheet} of ControlsFX.
     *
     * @return the property sheet items
     */
    public ObservableList<Item> getPropertySheetItems() {
        return FXCollections.observableArrayList();
    }
}
