

package calendar.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Common superclass for all controls in this framework.
 */
public final class Calendar {

    private static String version;

    /**
     * Returns the Calendar version number in the format major.minor.bug
     * (1.0.0).
     *
     * @return the Calendar version number
     */
    public static String getVersion() {
        if (version == null) {

            InputStream stream = Calendar.class.getResourceAsStream("version.properties");
            Properties props = new Properties();
            try {
                props.load(stream);
            } catch (IOException ex) {
                LoggingDomain.CONFIG.throwing(Calendar.class.getName(), "getVersion()", ex);
            }

            version = props.getProperty("calendar.version", "1.0.0");

            LoggingDomain.CONFIG.info("Calendar Version: " + version);
        }
        return version;
    }
}
