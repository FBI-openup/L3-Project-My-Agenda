
package calendar.view;

import impl.calendar.view.WeekDayViewSkin;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.MapChangeListener;
import javafx.scene.control.Skin;

/**
 * A specialization of the regular {@link DayView} in order to support some customized
 * styling / customized behaviour. Additionally, this view always has a reference to the
 * {@link WeekView} where it is being used.
 */
public class WeekDayView extends DayView {

    private static final String WEEKDAY_VIEW = "weekday-view";

    /**
     * Constructs a new day view.
     */
    public WeekDayView() {
        getStyleClass().add(WEEKDAY_VIEW);

        MapChangeListener<? super Object, ? super Object> propertiesListener = change -> {
            if (change.wasAdded()) {
                if (change.getKey().equals("week.view")) {
                    WeekView view = (WeekView) change.getValueAdded();
                    weekView.set(view);
                }
            }
        };

        getProperties().addListener(propertiesListener);
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new WeekDayViewSkin(this);
    }

    private final ReadOnlyObjectWrapper<WeekView> weekView = new ReadOnlyObjectWrapper<>(this, "weekView");

    /**
     * The week view where the view is being used.
     *
     * @return the week view
     */
    public final ReadOnlyObjectProperty<WeekView> weekViewProperty() {
        return weekView;
    }

    /**
     * Returns the value of {@link #weekViewProperty()}.
     *
     * @return the week view
     */
    public final WeekView getWeekView() {
        return weekView.get();
    }
}
