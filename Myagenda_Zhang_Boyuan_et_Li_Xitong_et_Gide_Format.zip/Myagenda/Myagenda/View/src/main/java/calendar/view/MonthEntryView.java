

package calendar.view;

import calendar.model.Entry;
import impl.calendar.view.MonthEntryViewSkin;
import javafx.scene.control.Skin;

/**
 * A specialized entry view used by the {@link MonthView}.
 */
public class MonthEntryView extends EntryViewBase<MonthView> {

    /**
     * Constructs a new entry view.
     *
     * @param entry
     *            the calendar entry for which the view will be created
     */
    public MonthEntryView(Entry<?> entry) {
        super(entry);

        setMouseTransparent(false);
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new MonthEntryViewSkin(this);
    }
}
