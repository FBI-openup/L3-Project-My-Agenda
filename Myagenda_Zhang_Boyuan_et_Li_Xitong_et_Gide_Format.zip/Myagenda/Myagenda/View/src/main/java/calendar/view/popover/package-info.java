/*xitong li,boyuan zhang*/

/**
 * A getting started set of views for creating popovers for calendar entries.
 */
package calendar.view.popover;

