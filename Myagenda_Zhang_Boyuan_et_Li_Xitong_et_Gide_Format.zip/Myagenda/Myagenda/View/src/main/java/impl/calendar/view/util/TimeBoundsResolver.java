/*xitong li,boyuan zhang*/

package impl.calendar.view.util;

import calendar.view.EntryViewBase;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@SuppressWarnings("javadoc")
public final class TimeBoundsResolver {

    public TimeBoundsResolver() {
    }

    private static Comparator<EntryViewBase<?>> additionalComparator;

    /**
     * The resolver always sorts entries based on their time bounds but when
     * entries have the same bounds the application might want to sort them based on
     * additional criteria. This can be implemented this way.
     *
     * @return
     */
    public static Comparator<EntryViewBase<?>> getAdditionalComparator() {
        return additionalComparator;
    }

    public static void setAdditionalComparator(Comparator<EntryViewBase<?>> additionalComparator) {
        TimeBoundsResolver.additionalComparator = additionalComparator;
    }

    public static <T extends EntryViewBase> List<Placement> resolve(List<T> entryViews) {

        final Comparator<T> comparator = (o1, o2) -> {

            int result = o1.compareTo(o2);

            if (result == 0 && additionalComparator != null) {
                return additionalComparator.compare(o1, o2);
            }

            return 0;
        };

        entryViews.sort(comparator);

        List<Placement> placements = new ArrayList<>();
        List<TimeBoundsCluster> clusters = new ArrayList<>();

        TimeBoundsCluster cluster = null;

        for (T view : entryViews) {
            if (view.isVisible()) {
                if (cluster == null || !cluster.intersects(view)) {
                    cluster = new TimeBoundsCluster();
                    clusters.add(cluster);
                }

                cluster.add(view);
            }
        }

        for (TimeBoundsCluster c : new ArrayList<>(clusters)) {
            placements.addAll(c.resolve());
        }

        return placements;
    }
}
