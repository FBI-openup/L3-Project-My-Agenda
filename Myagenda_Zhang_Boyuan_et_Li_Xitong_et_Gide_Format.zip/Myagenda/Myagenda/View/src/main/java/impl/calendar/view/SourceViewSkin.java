

package impl.calendar.view;

import calendar.model.Calendar;
import calendar.model.CalendarSource;
import calendar.view.SourceView;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.scene.control.CheckBox;
import javafx.scene.control.SkinBase;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.VBox;

@SuppressWarnings("javadoc")
public class SourceViewSkin extends SkinBase<SourceView> {

    private final VBox vbox;

    private final InvalidationListener updater = obs -> updateView();

    public SourceViewSkin(SourceView view) {
        super(view);

        vbox = new VBox();
        vbox.getStyleClass().add("container");

        getChildren().add(vbox);

        view.getCalendarSources().addListener(updater);
        updateView();
    }

    private void updateView() {
        vbox.getChildren().clear();
        for (CalendarSource source : getSkinnable().getCalendarSources()) {
            source.getCalendars().removeListener(updater);
            source.getCalendars().addListener(updater);

            VBox box = new VBox(8);
            box.getStyleClass().add("single-calendar-group");

            for (Calendar calendar : source.getCalendars()) {
                CheckBox checkBox = new CheckBox();
                checkBox.textProperty().bind(calendar.nameProperty());
                checkBox.getStyleClass().addAll("default-style-visibility-checkbox",
                        calendar.getStyle() + "-visibility-checkbox");
                Bindings.bindBidirectional(checkBox.selectedProperty(), getSkinnable().getCalendarVisibilityProperty(calendar));
                box.getChildren().add(checkBox);
            }

            if (getSkinnable().getCalendarSources().size() == 1) {
                vbox.getChildren().add(box);
            } else {
                TitledPane titledPane = new TitledPane();
                titledPane.textProperty().bind(source.nameProperty());
                titledPane.setContent(box);
                vbox.getChildren().add(titledPane);
            }
        }
    }
}
