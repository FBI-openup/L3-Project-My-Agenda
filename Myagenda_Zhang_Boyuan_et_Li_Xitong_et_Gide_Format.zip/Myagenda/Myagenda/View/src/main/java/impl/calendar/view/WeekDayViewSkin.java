

package impl.calendar.view;

import calendar.view.WeekDayView;
import calendar.view.WeekView;

import java.time.LocalDate;

public class WeekDayViewSkin extends DayViewSkin<WeekDayView> {

    public WeekDayViewSkin(WeekDayView view) {
        super(view);
    }

    @Override
    protected boolean isShowingTimeMarker() {
        WeekDayView dayView = getSkinnable();
        WeekView weekView = dayView.getWeekView();

        if (weekView != null) {
            LocalDate today = getSkinnable().getToday();

            LocalDate weekStart = weekView.getStartDate();
            LocalDate weekEnd = weekView.getEndDate();

            return !(weekStart.isAfter(today) || weekEnd.isBefore(today));

        }

        return false;
    }


    @Override
    protected boolean isShowingTimeTodayMarker() {
        WeekDayView dayView = getSkinnable();
        return dayView.getDate().equals(dayView.getToday());
    }
}
