/*xitong li,boyuan zhang*/

package impl.calendar.view.page;

import calendar.view.MonthSheetView;
import calendar.view.YearView;
import calendar.view.page.YearPage;
import javafx.scene.Node;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.StackPane;

@SuppressWarnings("javadoc")
public class YearPageSkin extends PageBaseSkin<YearPage> {

    private YearView yearView;
    private MonthSheetView sheetView;
    private StackPane stackPane;

    public YearPageSkin(YearPage view) {
        super(view);

        view.addEventFilter(ScrollEvent.SCROLL, this::handleScroll);
        view.displayModeProperty().addListener(it -> updateVisibility());

        updateVisibility();
    }

    private void updateVisibility() {
        switch (getSkinnable().getDisplayMode()) {
            case COLUMNS:
                yearView.setManaged(false);
                yearView.setVisible(false);
                sheetView.setManaged(true);
                sheetView.setVisible(true);
                if(!stackPane.getChildren().contains(sheetView)) {
                    stackPane.getChildren().add(sheetView);
                }
                break;
            case GRID:
                yearView.setManaged(true);
                yearView.setVisible(true);
                sheetView.setManaged(false);
                sheetView.setVisible(false);
                if(!stackPane.getChildren().contains(yearView)) {
                    stackPane.getChildren().add(yearView);
                }
                break;
        }
    }

    private void handleScroll(ScrollEvent evt) {
        YearPage yearPage = getSkinnable();
        double delta = evt.getDeltaX();
        if (delta == 0) {
            return;
        }
        if (delta < 0) {
            yearPage.goForward();
        } else if (delta > 0) {
            yearPage.goBack();
        }
    }

    @Override
    protected Node createContent() {
        stackPane = new StackPane();

        this.sheetView = getSkinnable().getMonthSheetView();
        this.sheetView.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        this.yearView = getSkinnable().getYearView();
        this.yearView.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        return stackPane;
    }
}
