/*xitong li,boyuan zhang*/

package impl.calendar.view.util;

import calendar.model.Entry;
import calendar.view.DayView;
import calendar.view.DraggedEntry;
import calendar.view.EntryViewBase;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("javadoc")
public final class VisualBoundsColumn {

    private List<EntryViewBase<?>> entryViewBases;

    public void add(EntryViewBase<?> view) {
        if (entryViewBases == null) {
            entryViewBases = new ArrayList<>();
        }

        entryViewBases.add(view);
    }

    public boolean hasRoomFor(EntryViewBase<?> entryView, DayView dayView, double contentWidth) {
        if (entryViewBases == null) {
            return true;
        }

        Entry<?> entry = entryView.getEntry();

        VisualBoundsResolver.Range entryRange = VisualBoundsResolver.getRange(entryView, dayView, contentWidth);

        if (entry.isFullDay()) {
            entryRange.y1 = 0;
            entryRange.y2 = dayView.getHeight();
        }

        for (EntryViewBase<?> otherView : entryViewBases) {

            if (isSameEntry(entryView, otherView)) {
                continue;
            }

            VisualBoundsResolver.Range otherRange = VisualBoundsResolver.getRange(otherView, dayView, contentWidth);

            if (entry.isFullDay()) {
                otherRange.y1 = 0;
                otherRange.y2 = dayView.getHeight();
            }

            if (entryRange.y1 < otherRange.y2 && entryRange.y2 > otherRange.y1) {

                /*
                 * The two activities intersect, so we can not use this column
                 * for the passed activity.
                 */
                return false;
            }
        }

        return true;
    }

    private boolean isSameEntry(EntryViewBase<?> viewA, EntryViewBase<?> viewB) {
        Entry<?> entryA = viewA.getEntry();
        Entry<?> entryB = viewB.getEntry();

        if (entryA instanceof DraggedEntry) {
            return isSameEntry((DraggedEntry) entryA, entryB);
        }

        if (entryB instanceof DraggedEntry) {
            return isSameEntry((DraggedEntry) entryB, entryA);
        }

        return false;
    }

    private boolean isSameEntry(DraggedEntry draggedEntry, Entry<?> entry) {
        if (entry.isRecurrence()) {
            return draggedEntry.getOriginalEntry().getRecurrenceSourceEntry() == entry.getRecurrenceSourceEntry();
        }

        return draggedEntry.getOriginalEntry() == entry;
    }

    public List<EntryViewBase<?>> getEntryViews() {
        return entryViewBases;
    }
}
