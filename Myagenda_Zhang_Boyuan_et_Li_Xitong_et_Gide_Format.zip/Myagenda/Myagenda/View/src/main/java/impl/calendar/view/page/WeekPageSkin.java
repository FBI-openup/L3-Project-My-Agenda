/*xitong li,boyuan zhang*/

package impl.calendar.view.page;

import calendar.view.DetailedWeekView;
import calendar.view.page.WeekPage;
import javafx.beans.binding.Bindings;
import javafx.scene.Node;

@SuppressWarnings("javadoc")
public class WeekPageSkin extends PageBaseSkin<WeekPage> {

    public WeekPageSkin(WeekPage view) {
        super(view);
    }

    @Override
    protected Node createContent() {
        WeekPage weekPage = getSkinnable();
        DetailedWeekView detailedWeekView = weekPage.getDetailedWeekView();

        weekPage.bind(detailedWeekView, true);

        Bindings.bindBidirectional(detailedWeekView.startTimeProperty(), weekPage.startTimeProperty());
        Bindings.bindBidirectional(detailedWeekView.endTimeProperty(), weekPage.endTimeProperty());

        return detailedWeekView;
    }
}
