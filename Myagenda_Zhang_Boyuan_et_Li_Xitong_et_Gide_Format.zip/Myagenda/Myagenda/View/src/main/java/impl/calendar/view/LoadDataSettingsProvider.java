/*xitong li,boyuan zhang*/

package impl.calendar.view;

import calendar.model.Calendar;
import calendar.model.CalendarSource;
import javafx.scene.control.Control;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

public interface LoadDataSettingsProvider {

    String getLoaderName();

    LocalDate getLoadStartDate();

    LocalDate getLoadEndDate();

    ZoneId getZoneId();

    List<CalendarSource> getCalendarSources();

    Control getControl();

    boolean isCalendarVisible(Calendar calendar);
}
