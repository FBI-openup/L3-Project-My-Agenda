/*xitong li,boyuan zhang*/

package impl.calendar.view;

import javafx.scene.control.TextField;

public final class NumericTextField extends TextField {

    public NumericTextField() {
        focusedProperty().addListener(it -> {
            if (isFocused()) {
                selectAll();
            }
        });
    }

    @Override
    public void replaceText(int start, int end, String s) {
        super.replaceText(start, end, s.replaceAll("[^0-9]", ""));
    }

    @Override
    public void replaceSelection(String s) {
        super.replaceSelection(s.replaceAll("[^0-9]", ""));
    }
}
