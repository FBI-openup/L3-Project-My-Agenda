/*xitong li,boyuan zhang*/

package impl.calendar.view.util;

import calendar.view.EntryViewBase;

import java.util.Objects;

@SuppressWarnings("javadoc")
public final class Placement {

    private final int columnIndex;

    private final int columnCount;

    private final EntryViewBase<?> entryViewBase;

    public Placement(EntryViewBase<?> activity, int columnIndex, int columnCount) {
        this.entryViewBase = Objects.requireNonNull(activity);
        this.columnIndex = columnIndex;
        this.columnCount = columnCount;
    }

    public EntryViewBase<?> getEntryView() {
        return entryViewBase;
    }

    public int getColumnIndex() {
        return columnIndex;
    }

    public int getColumnCount() {
        return columnCount;
    }

    @Override
    public String toString() {
        return "Placement [columnIndex=" + columnIndex + ", columnCount="
                + columnCount + ", entry=" + entryViewBase.getEntry() + "]";
    }
}
