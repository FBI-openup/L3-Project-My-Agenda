package calendar.app;

public class CalendarAppLauncher {

    public static void main(String[] args) {
        CalendarApp.main(args);
    }
}
