package calendar.app;

import calendar.model.Calendar;
import calendar.model.Calendar.Style;
import calendar.model.CalendarSource;
import calendar.view.CalendarView;
import fr.brouillard.oss.cssfx.CSSFX;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.LocalTime;

public class CalendarApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        CalendarView calendarView = new CalendarView();
        calendarView.setEnableTimeZoneSupport(true);

        Calendar ZHANGBoyuan = new Calendar("Zhang");
        Calendar LiXitong = new Calendar("Li");
        Calendar Gide = new Calendar("Gide");
        Calendar Thai = new Calendar("Thai");
        Calendar someone = new Calendar("Someone");
        Calendar birthdays = new Calendar("Birthdays");
        Calendar holidays = new Calendar("Holidays");

        ZHANGBoyuan.setShortName("Z");
        LiXitong.setShortName("L");
        Gide.setShortName("G");
        Thai.setShortName("T");
        someone.setShortName("S");
        birthdays.setShortName("B");
        holidays.setShortName("H");

        ZHANGBoyuan.setStyle(Style.STYLE1);
        LiXitong.setStyle(Style.STYLE2);
        Gide.setStyle(Style.STYLE3);
        Thai.setStyle(Style.STYLE4);
        someone.setStyle(Style.STYLE5);
        birthdays.setStyle(Style.STYLE6);
        holidays.setStyle(Style.STYLE7);

        CalendarSource familyCalendarSource = new CalendarSource("Group");
        familyCalendarSource.getCalendars().addAll(birthdays, holidays, ZHANGBoyuan, LiXitong, Gide, Thai, someone);
        calendarView.getCalendarSources().setAll(familyCalendarSource);
        calendarView.setRequestedTime(LocalTime.now());

        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(calendarView); // introPane);

        Thread updateTimeThread = new Thread("Calendar: Update Time Thread") {
            @Override
            public void run() {
                while (true) {
                    Platform.runLater(() -> {
                        calendarView.setToday(LocalDate.now());
                        calendarView.setTime(LocalTime.now());
                    });

                    try {
                        // update every 10 seconds
                        sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        updateTimeThread.setPriority(Thread.MIN_PRIORITY);
        updateTimeThread.setDaemon(true);
        updateTimeThread.start();

        Scene scene = new Scene(stackPane);
        scene.focusOwnerProperty().addListener(it -> System.out.println("focus owner: " + scene.getFocusOwner()));
        CSSFX.start(scene);

        primaryStage.setTitle("Calendar");
        primaryStage.setScene(scene);
        primaryStage.setWidth(1300);
        primaryStage.setHeight(1000);
        primaryStage.centerOnScreen();
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
